// Hub Schedule Auth — background service worker
// Watches for EventTemple login, syncs cookies to the Pi

const PI_URLS = [
  'http://tech.thehub',
  'http://100.98.118.40:8090',
  'http://10.0.81.231:8090'
];

const COOLDOWN_MS = 60 * 60 * 1000; // 1 hour
let lastSync = 0;

// Watch for completed navigations on eventtemple.com
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  if (!tab.url || !tab.url.includes('eventtemple.com')) return;
  // Skip login/auth pages — user hasn't finished logging in yet
  if (tab.url.includes('/login') || tab.url.includes('/auth')) return;

  // Cooldown — don't spam on every EventTemple page navigation
  const now = Date.now();
  if (now - lastSync < COOLDOWN_MS) return;

  syncCookies(tabId);
});

async function syncCookies(tabId) {
  try {
    const cookies = await chrome.cookies.getAll({ domain: '.eventtemple.com' });
    if (!cookies.length) {
      setBadge('!', '#ff4444');
      return;
    }

    const payload = {
      cookies: cookies.map(c => ({
        name: c.name,
        value: c.value,
        domain: c.domain,
        path: c.path,
        expires: c.expirationDate || -1,
        httpOnly: c.httpOnly,
        secure: c.secure,
        sameSite: c.sameSite
      }))
    };

    let synced = false;
    for (const baseUrl of PI_URLS) {
      try {
        const resp = await fetch(`${baseUrl}/api/auth`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        if (!resp.ok) continue;
        const result = await resp.json();
        if (result.ok) {
          synced = true;
          lastSync = Date.now();
          setBadge('\u2713', '#10b981');
          // Clear badge after 10s
          setTimeout(() => setBadge('', ''), 10000);
          console.log(`[Hub Auth] Synced ${cookies.length} cookies via ${baseUrl}`);
          break;
        }
      } catch (e) {
        // Try next URL
        continue;
      }
    }

    if (!synced) {
      setBadge('!', '#ff4444');
      console.warn('[Hub Auth] Failed to sync to any Pi URL');
    }
  } catch (e) {
    setBadge('!', '#ff4444');
    console.error('[Hub Auth] Error:', e);
  }
}

function setBadge(text, color) {
  chrome.action.setBadgeText({ text });
  if (color) chrome.action.setBadgeBackgroundColor({ color });
}
